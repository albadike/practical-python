# setup.py
import setuptools

setuptools.setup(
    name="porty",
    version="0.0.1",
    author="Fort Awesome",
    author_email="aj@awesome.com",
    description="Test Package Code",
    packages=setuptools.find_packages(),
)